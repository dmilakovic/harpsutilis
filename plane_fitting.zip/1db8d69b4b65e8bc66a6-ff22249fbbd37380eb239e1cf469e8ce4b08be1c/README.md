Python version of the MATLAB code in this Stack Overflow post:
http://stackoverflow.com/a/18648210/97160

The example shows how to determine the best-fit plane/surface
(1st or higher order polynomial) over a set of three-dimensional points.

Implemented in Python + NumPy + SciPy + matplotlib.

![quadratic_surface](http://i.imgur.com/hquieGA.png)
